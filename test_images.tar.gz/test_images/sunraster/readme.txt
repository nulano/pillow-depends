From https://samples.libav.org/image-samples/sunrast/
Original readme follows:

Sun Rasterfiles 

MARBLES.SUN  was retrieved from fileformat.info
lena-{8,24}* were created with Netpbm
lena-1*      were created with The Gimp
32bpp*       32 bit per pixel sample
4bpp*         4 bit per pixel sample
gray*        grayscale sample
